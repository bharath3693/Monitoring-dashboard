import React from 'react'
// import { Link } from 'react-router-dom'
import { SideButton } from '../MyComponents/smallComponents/SideButton'
// import { Home } from './Home'
// import { CountDevices } from './smallComponents/CountDevices'
// import { SideButton } from "./smallComponents/SideButton"

export const Sidebar = () => {
    return (
        <div className="col-2 p-0 m-0 rounded-right sidebar-color shadow-max pt-2 sidebar">
            {/* <div className='row w-100 text-center p-2'>
                <div className='col-2'>
                    <img alt="logoman" src='https://img.icons8.com/external-vitaliy-gorbachev-flat-vitaly-gorbachev/512/external-dashboard-blogger-vitaliy-gorbachev-flat-vitaly-gorbachev.png' height={50} width={50}></img>
                </div>
                <div className='col-10 text-white mt-2'>
                    <h6>TINY ML DASHBOARD</h6>
                </div>
            </div>
            <hr className='mb-1'></hr> */}
            <h3 className='text-white roboto ms-2'>Menu</h3>
            <SideButton id={'dashboard-btn'} name={'Dashboard'} path={'/'} />
            <SideButton id={'edgedevice-btn'} name={'Edge Devices'} path={'/edge'} />
            <SideButton id={'ggdevice-btn'} name={'Green Grass Devices'} path={'/edge'} />
        </div>
        // <div>
        //     <div className="overlay"></div>
        //         <nav className="navbar navbar-inverse fixed-top shadow-max" id="sidebar-wrapper" role="navigation">
        //             <ul className="nav sidebar-nav">
        //                 <div className="sidebar-header">
        //                     <div className="sidebar-brand">
        //                         <a href="/">Menu</a>
        //                     </div>
        //                 </div>

        //                 <li>
        //                     <Link to="/">Home</Link>
        //                 </li>
        //                 <li>
        //                     <Link to="/edge">Edge Devices</Link>
        //                 </li>
        //                 {/* <li><a href="/edge">Edge Devices</a></li> */}
        //             </ul>


        //         </nav>

        // </div>
    )
}