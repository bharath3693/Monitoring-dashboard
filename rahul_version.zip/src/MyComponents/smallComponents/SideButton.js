import React from 'react'
import { Link } from 'react-router-dom'

export const SideButton = (props) => {
  return (
    <div className='sidebutton sidebutton-color' id={props.id}>

      <Link to={props.path}><button className="btn btn-lg btn-block w-100 text-white" >{props.name}</button></Link>
    </div>
  )
}
