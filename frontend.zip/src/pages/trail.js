{/* <Navbar /> */}
      {/* <div className="container pb-3">
      <div className="row container">        
        <div className="row-sm-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Edge Devices - Raspberry Pi 
              <button
                onClick={() =>
                  setClick1(clicked1 === 0 ? clicked1 + 1 : clicked1 - 1)
                }
                className="btn btn-color mx-2 text-white"
              >
                {clicked1 === 1 ? "Hide Details" : "View Details"}
              </button>
              </h5>
              
            </div>
            {clicked1 === 1 ? <Table1 data={table1_data} /> : ""}
          </div>
        </div>

        <div className="row-sm-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">
                Leaving devices-Other Devices-OpenMV board
                <button
                onClick={() =>
                  setClick2(clicked2 === 0 ? clicked2 + 1 : clicked2 - 1)
                }
                className="btn btn-color mx-2 text-white"
              >
                {clicked2 === 1 ? "Hide Details" : "View Details"}
              </button>
              </h5>
              
            </div>
            {clicked2 === 1 ? <Table2 data={table2_data} /> : ""}
          </div>
        </div>
      </div>
      </div> */}