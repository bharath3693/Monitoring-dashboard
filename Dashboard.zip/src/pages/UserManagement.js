import React, { useState } from 'react';
import { Navbar } from '../MyComponents/Navbar';
import { Sidebar } from '../MyComponents/Sidebar';

export const UserManagement = () => {

    const [hide, setHide] = useState(1);


    return (
        <>
            <Navbar />        
            <div className="row p-0 m-0">
                <Sidebar />            
                <div className="col-10 pt-3 m-0 p-2 pt-4">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Pending Request</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Accepted</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Rejected</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div className='p-3'>
                                <b className='big-font text-uppercase'>Pending Requests </b>
                                <table className='table table-bordered table-striped'>
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>User Name</th>
                                            <th>Email</th>
                                            <th>Approval</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Sai Bharath</td>
                                            <td>bharath@gmail.com</td>
                                            <td><button className='btn btn-sm btn-success'>Approve</button> / <button className='btn btn-sm btn-danger'>Reject</button></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div className="p-3">
                                <b className='big-font text-uppercase'>Accepted Requests </b>
                                <table className='table table-bordered table-striped'>
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>User Name</th>
                                            <th>Email</th>
                                            {/* <th>Approval</th> */}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Rahul</td>
                                            <td>rahul@gmail.com</td>
                                            {/* <td><button className='btn btn-sm btn-success'>Approve</button> / <button className='btn btn-sm btn-danger'>Reject</button></td> */}
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <div className="p-3">
                                <b className='big-font text-uppercase'>Rejected Request</b>
                                <table className='table table-bordered table-striped'>
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>User Name</th>
                                            <th>Email</th>
                                            <th>Reasons</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Sujith</td>
                                            <td>sujith@gmail.com</td>

                                            <td>Reason for the rejection.</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

